
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SocialNetwork {

    private Map<String, List<String>> network;

    public SocialNetwork() {
        this.network = new HashMap<>();
    }

    public void addFriend(String person, String friend) {
        if (!network.containsKey(person)) {
            network.put(person, new ArrayList<>());
        }
        network.get(person).add(friend);

        if (!network.containsKey(friend)) {
            network.put(friend, new ArrayList<>());
        }
        network.get(friend).add(person);
    }

    public List<String> getFriends(String person) {
        return network.getOrDefault(person, new ArrayList<>());
    }

}

