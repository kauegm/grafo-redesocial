import java.util.List;

public class Main {

    public static void main(String[] args) {

        SocialNetwork socialNetwork = new SocialNetwork();

        // Adicionar amigos
        socialNetwork.addFriend("Adriana", "Beto");
        socialNetwork.addFriend("Adriana", "Charles");
        socialNetwork.addFriend("Beto", "José");
        socialNetwork.addFriend("Charles", "João");

        // Obter amigos de uma pessoa
        List<String> aliceFriends = socialNetwork.getFriends("Alice");
        System.out.println("Amigos de Alice: " + aliceFriends);

        List<String> bobFriends = socialNetwork.getFriends("Bob");
        System.out.println("Amigos de Bob: " + bobFriends);

    }
}